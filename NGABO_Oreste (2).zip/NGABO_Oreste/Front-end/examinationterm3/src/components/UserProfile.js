// UserProfile.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UserProfile = ({ userId }) => {
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:5000/api/userdetails/${userId}`)
      .then(response => {
        setUserData(response.data);
      })
      .catch(error => {
        console.error('Error fetching user data:', error);
      });
  }, [userId]);

  if (!userData) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container p-5">
      <h2>User Profile</h2>
      <div>
        <strong>Title: </strong> {userData.title}
      </div>
      <div>
        <strong>Name: </strong> {userData.firstName} {userData.lastName}
      </div>
      <div>
        <strong>Position: </strong> {userData.position}
      </div>
      <div>
        <strong>Company: </strong> {userData.company}
      </div>
      <div>
        <strong>Business Arena: </strong> {userData.businessArena}
      </div>
      <div>
        <strong>Employees: </strong> {userData.employees}
      </div>
      <div>
        <strong>Street + Nr: </strong> {userData.streetNr}
      </div>
      <div>
        <strong>Additional Info: </strong> {userData.additionalInfo}
      </div>
      <div>
        <strong>Zip Code: </strong> {userData.zipCode}
      </div>
      <div>
        <strong>Place: </strong> {userData.place}
      </div>
      <div>
        <strong>Country: </strong> {userData.country}
      </div>
      <div>
        <strong>Phone Number: </strong> {userData.code} {userData.phoneNumber}
      </div>
      <div>
        <strong>Email: </strong> {userData.email}
      </div>
    </div>
  );
};

export default UserProfile;
